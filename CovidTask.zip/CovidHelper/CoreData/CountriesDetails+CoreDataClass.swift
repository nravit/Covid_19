//
//  CountriesDetails+CoreDataClass.swift
//  CovidHelper
//
//  Created by Raviteja on 16/05/21.
//
//

import Foundation
import CoreData

@objc(CountriesDetails)
public class CountriesDetails: NSManagedObject {

}
