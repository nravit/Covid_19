//
//  Country+CoreDataClass.swift
//  CovidHelper
//
//  Created by Raviteja on 16/05/21.
//
//

import Foundation
import CoreData

@objc(Country)
public class Country: NSManagedObject {

}
